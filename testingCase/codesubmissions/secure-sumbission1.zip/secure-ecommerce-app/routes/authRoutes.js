import express from 'express';
import { register, login, profile } from '../controllers/authController.js';
import { body } from 'express-validator';

const router = express.Router();

router.post('/register', [
  body('email').isEmail(),
  body('password').isLength({ min: 8 })
], register);

router.post('/login', login);
router.get('/profile', profile);

export default router;
