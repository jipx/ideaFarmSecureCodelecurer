INSERT INTO users (email, password, role) VALUES
('admin@example.com', '$2b$12$Z5dC6xMpPbUoDnGH6wYWAeuzNAX.R9l0DbzFgAXNtk6M0CKDg8BOC', 'admin'),
('user@example.com',  '$2b$12$wU.Zg5w4AhiNqEDjIURl6ekvF6FcSwbTqI8kWH30HbpPMpt2u0DFe', 'user');

INSERT INTO products (name, description, price) VALUES
('Wireless Mouse', 'Ergonomic wireless mouse with USB receiver', 29.99),
('Bluetooth Speaker', 'Waterproof portable speaker with deep bass', 49.95),
('Gaming Keyboard', 'Mechanical keyboard with RGB lighting', 89.50);

INSERT INTO cart (user_id, product_id, quantity)
SELECT u.id, p.id, 2 FROM users u, products p
WHERE u.email = 'user@example.com' AND p.name = 'Wireless Mouse';

INSERT INTO orders (user_id, total, paid)
SELECT u.id, 59.98, TRUE FROM users u
WHERE u.email = 'user@example.com';

INSERT INTO reviews (user_id, product_id, comment, rating)
SELECT u.id, p.id, 'Great quality for the price!', 5
FROM users u, products p
WHERE u.email = 'user@example.com' AND p.name = 'Bluetooth Speaker';

INSERT INTO reviews (user_id, product_id, comment, rating)
SELECT u.id, p.id, 'RGB lighting is awesome!', 4
FROM users u, products p
WHERE u.email = 'user@example.com' AND p.name = 'Gaming Keyboard';
