import pool from '../models/db.js';
import jwt from 'jsonwebtoken';

function isAdmin(decoded) {
  return decoded.role === 'admin';
}

export const getProducts = async (req, res) => {
  const result = await pool.query('SELECT * FROM products');
  res.json(result.rows);
};

export const addProduct = async (req, res) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  if (!isAdmin(decoded)) return res.status(403).json({ error: 'Forbidden' });

  const { name, description, price } = req.body;
  const result = await pool.query(
    'INSERT INTO products (name, description, price) VALUES ($1, $2, $3) RETURNING *',
    [name, description, price]
  );
  res.status(201).json(result.rows[0]);
};

export const deleteProduct = async (req, res) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  if (!isAdmin(decoded)) return res.status(403).json({ error: 'Forbidden' });

  await pool.query('DELETE FROM products WHERE id = $1', [req.params.id]);
  res.json({ message: 'Product deleted' });
};
