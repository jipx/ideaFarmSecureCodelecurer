import pool from '../models/db.js';
import jwt from 'jsonwebtoken';

export const addToCart = async (req, res) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  const { productId, quantity } = req.body;
  await pool.query(
    'INSERT INTO cart (user_id, product_id, quantity) VALUES ($1, $2, $3)',
    [decoded.id, productId, quantity]
  );
  res.json({ message: 'Added to cart' });
};
