import pool from '../models/db.js';
import jwt from 'jsonwebtoken';

export const submitReview = async (req, res) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  const { comment, rating } = req.body;
  await pool.query(
    'INSERT INTO reviews (user_id, product_id, comment, rating) VALUES ($1, $2, $3, $4)',
    [decoded.id, req.params.id, comment, rating]
  );
  res.json({ message: 'Review submitted' });
};
