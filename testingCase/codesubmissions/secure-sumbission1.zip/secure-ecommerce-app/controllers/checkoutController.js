import pool from '../models/db.js';
import jwt from 'jsonwebtoken';

export const checkout = async (req, res) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  const cart = await pool.query('SELECT * FROM cart WHERE user_id = $1', [decoded.id]);
  if (cart.rows.length === 0) return res.status(400).json({ error: 'Cart is empty' });

  const total = cart.rows.reduce((sum, item) => sum + item.quantity * 10, 0); // dummy pricing
  await pool.query(
    'INSERT INTO orders (user_id, total, paid) VALUES ($1, $2, $3)',
    [decoded.id, total, true]
  );
  await pool.query('DELETE FROM cart WHERE user_id = $1', [decoded.id]);
  res.json({ message: 'Checkout successful' });
};
